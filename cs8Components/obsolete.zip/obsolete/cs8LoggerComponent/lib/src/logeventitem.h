#ifndef LOGEVENTITEM_H_
#define LOGEVENTITEM_H_

class logEventItem
{
	
public:
	logEventItem();
	virtual ~logEventItem();
};

#endif /*LOGEVENTITEM_H_*/
