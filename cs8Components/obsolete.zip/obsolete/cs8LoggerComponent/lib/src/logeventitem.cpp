#include "logeventitem.h"

logEventItem::logEventItem()
{
}

logEventItem::~logEventItem()
{
}
