//
// C++ Interface: cs8LoggerComponent
//
// Description: 
//
//
// Author: Volker Drewer-Gutland <volker.drewer@gmx.de>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//

#include "cs8loggerwidget.h"
#include "cs8statisticplot.h"
#include "cs8logstatisticswidget.h"
