#ifndef __CS8MODBUSCOMPONENT_H__
#define __CS8MODBUSCOMPONENT_H__

// place your code here

#include "cs8modbusconfigfile.h"
#include "cs8modbusdelegate.h"
#include "cs8wagonode.h"
#include "cs8wagonodewidget.h"
#include "cs8modbuswidget.h"
#include "cs8modbusitem.h"
#include "cs8wagonewaddresswidget.h"


#endif // __CS8MODBUSCOMPONENT_H__
