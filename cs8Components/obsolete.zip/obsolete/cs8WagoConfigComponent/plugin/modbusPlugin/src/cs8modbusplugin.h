#ifndef CS8MODBUSPLUGIN_H
#define CS8MODBUSPLUGIN_H
//
#include <QDesignerCustomWidgetInterface>
//
class cs8ModbusPlugin : public QObject, public QDesignerCustomWidgetInterface
{
    Q_OBJECT
    
    Q_INTERFACES ( QDesignerCustomWidgetInterface )
    
  public:
    cs8ModbusPlugin ( QObject* parent=0 );
    bool isContainer() const;
    bool isInitialized() const;
    QIcon icon() const;
    QString domXml() const;
    QString group() const;
    QString includeFile() const;
    QString name() const;
    QString toolTip() const;
    QString whatsThis() const;
    QWidget *createWidget ( QWidget *parent );
    void initialize ( QDesignerFormEditorInterface *core );
    
  private:
    bool initialized;
    
};
#endif
